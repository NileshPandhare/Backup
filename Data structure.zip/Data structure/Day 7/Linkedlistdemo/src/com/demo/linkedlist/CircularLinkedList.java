package com.demo.linkedlist;

public class CircularLinkedList {

}
