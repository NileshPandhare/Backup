package com.demo.SpringBootWebservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWebserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
