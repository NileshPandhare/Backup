
public class TestnewSwitchCase {

	public static void main(String[] args) {
		int i=2;
		switch(i) {
		case 1->{System.out.println("you selected 1");
		
		}
		case 2->{
			System.out.println("you selected 2");
		}
			
		}
	}

}
