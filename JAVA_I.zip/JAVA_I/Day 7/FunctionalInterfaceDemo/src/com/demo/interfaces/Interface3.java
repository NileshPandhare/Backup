package com.demo.interfaces;

public interface Interface3 {
     int compare(String x,String y);
}
